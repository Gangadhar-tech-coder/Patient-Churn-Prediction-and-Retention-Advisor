"""
Database Module — Patient Churn Prediction (PostgreSQL / SQLite Compatible)
===========================================================================
Manages users, predictions, and cohort datasets via SQLAlchemy.
"""

import os
import hashlib
import uuid
from sqlalchemy import create_engine, Column, String, Integer, Float, Text, ForeignKey, DateTime
from sqlalchemy.orm import declarative_base, sessionmaker
from sqlalchemy.sql import func

DB_DIR = os.path.dirname(os.path.abspath(__file__))
SQLITE_FALLBACK = f"sqlite:///{os.path.join(DB_DIR, 'patient_churn_prediction.db')}"

# Look for DATABASE_URL environment variable (Render PostgreSQL), fallback to SQLite
DATABASE_URL = os.getenv("DATABASE_URL", SQLITE_FALLBACK)

if DATABASE_URL and DATABASE_URL.startswith("postgres://"):
    DATABASE_URL = DATABASE_URL.replace("postgres://", "postgresql://", 1)

# Configure engine
if DATABASE_URL.startswith("sqlite"):
    engine = create_engine(DATABASE_URL, connect_args={"check_same_thread": False})
else:
    try:
        engine = create_engine(DATABASE_URL)
        # Test connection
        with engine.connect() as conn:
            pass
    except Exception:
        # Fallback to local SQLite if remote PostgreSQL is unreachable
        engine = create_engine(SQLITE_FALLBACK, connect_args={"check_same_thread": False})

SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()


class User(Base):
    __tablename__ = "users"
    id = Column(String, primary_key=True)
    name = Column(String, nullable=False)
    email = Column(String, unique=True, nullable=False)
    password_hash = Column(String, nullable=False)
    created_at = Column(DateTime, server_default=func.now())


class Prediction(Base):
    __tablename__ = "predictions"
    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(String, ForeignKey("users.id"))
    patient_data = Column(Text)
    probability = Column(Float)
    risk_level = Column(String)
    primary_reason = Column(String)
    retention_advice = Column(Text)
    created_at = Column(DateTime, server_default=func.now())


class CohortDataset(Base):
    __tablename__ = "cohort_datasets"
    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(String, ForeignKey("users.id"))
    filename = Column(String)
    total_patients = Column(Integer)
    high_risk = Column(Integer)
    medium_risk = Column(Integer)
    low_risk = Column(Integer)
    created_at = Column(DateTime, server_default=func.now())


def init_db():
    """Initialize database tables."""
    Base.metadata.create_all(bind=engine)


def hash_password(password: str) -> str:
    return hashlib.sha256(password.encode()).hexdigest()


def create_user(name: str, email: str, password: str) -> dict:
    user_id = str(uuid.uuid4())
    pw_hash = hash_password(password)
    db = SessionLocal()
    try:
        existing = db.query(User).filter(User.email == email).first()
        if existing:
            return None
        new_user = User(id=user_id, name=name, email=email, password_hash=pw_hash)
        db.add(new_user)
        db.commit()
        return {"id": user_id, "name": name, "email": email}
    except Exception:
        db.rollback()
        return None
    finally:
        db.close()


def authenticate_user(email: str, password: str) -> dict:
    pw_hash = hash_password(password)
    db = SessionLocal()
    try:
        user = db.query(User).filter(User.email == email, User.password_hash == pw_hash).first()
        if user:
            return {"id": user.id, "name": user.name, "email": user.email}
        return None
    finally:
        db.close()


def get_user_by_id(user_id: str) -> dict:
    db = SessionLocal()
    try:
        user = db.query(User).filter(User.id == user_id).first()
        if user:
            return {"id": user.id, "name": user.name, "email": user.email}
        return None
    finally:
        db.close()


def save_prediction(user_id: str, patient_data: str, probability: float,
                    risk_level: str, primary_reason: str, retention_advice: str):
    db = SessionLocal()
    try:
        pred = Prediction(
            user_id=user_id,
            patient_data=patient_data,
            probability=probability,
            risk_level=risk_level,
            primary_reason=primary_reason,
            retention_advice=retention_advice
        )
        db.add(pred)
        db.commit()
    finally:
        db.close()


def save_cohort(user_id: str, filename: str, total: int, high: int, med: int, low: int):
    db = SessionLocal()
    try:
        cohort = CohortDataset(
            user_id=user_id,
            filename=filename,
            total_patients=total,
            high_risk=high,
            medium_risk=med,
            low_risk=low
        )
        db.add(cohort)
        db.commit()
    finally:
        db.close()


def get_user_predictions(user_id: str, limit: int = 50) -> list:
    db = SessionLocal()
    try:
        preds = db.query(Prediction).filter(Prediction.user_id == user_id)\
                    .order_by(Prediction.created_at.desc())\
                    .limit(limit).all()
        return [{
            "id": p.id,
            "user_id": p.user_id,
            "patient_data": p.patient_data,
            "probability": p.probability,
            "risk_level": p.risk_level,
            "primary_reason": p.primary_reason,
            "retention_advice": p.retention_advice,
            "created_at": str(p.created_at)
        } for p in preds]
    finally:
        db.close()


def get_user_analytics(user_id: str) -> dict:
    db = SessionLocal()
    try:
        preds = db.query(Prediction).filter(Prediction.user_id == user_id).all()
        cohorts = db.query(CohortDataset).filter(CohortDataset.user_id == user_id)\
                    .order_by(CohortDataset.created_at.desc()).limit(10).all()

        probabilities = [p.probability for p in preds] if preds else []
        return {
            "total_evaluated": len(preds),
            "avg_churn": round(sum(probabilities) / len(probabilities) * 100, 1) if probabilities else 0,
            "high_risk_count": sum(1 for p in preds if p.risk_level == "High"),
            "medium_risk_count": sum(1 for p in preds if p.risk_level == "Medium"),
            "low_risk_count": sum(1 for p in preds if p.risk_level == "Low"),
            "cohort_uploads": [{
                "id": c.id,
                "filename": c.filename,
                "total_patients": c.total_patients,
                "high_risk": c.high_risk,
                "medium_risk": c.medium_risk,
                "low_risk": c.low_risk,
                "created_at": str(c.created_at)
            } for c in cohorts],
        }
    finally:
        db.close()


# Auto-init tables
init_db()
